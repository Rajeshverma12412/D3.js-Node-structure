
var http = require("http");
var fs = require("fs");
var path = require("path");
const _ = require("lodash");

let jsonData = [
  {
    "name": "Top Level",
    "parent": "null",
    "value": 20,
    // "type": "black",
    // "level": "red",
    "children": [
      {
        "name": "Level 2: A",
        "parent": "Top Level",
        "value": 15,
        "type": "grey",
        "level": "red",
        "children": [
          {
            "name": "Son of A",
            "parent": "Level 2: A",
            "value": 5,
            "type": "steelblue",
            "level": "orange"
          },
          {
            "name": "Daughter of A",
            "parent": "Level 2: A",
            "value": 8,
            "type": "steelblue",
            "level": "red"
          }
        ]
      },
      {
        "name": "Level 2: B",
        "parent": "Top Level",
        "value": 10,
        "type": "grey",
        "level": "green"
      }
    ]
  }
];
  fs.writeFileSync('./d3-view.json', JSON.stringify(jsonData));
//create a server object:
http.createServer(function (req, res) {
    console.log(req.url);
    if (req.url == "/data") {
        // perform the business logic / process the x
        // let json = fs.readFileSync('./d3-view.json');
      let d3 = [d3Structure];
      res.write(JSON.stringify(d3)); //write a response to the client
      //  res.write(JSON.stringify(jsonData));
      res.end(); //end the response
    // res.end(jsonData);
    }else if (req.url == "/node-view") {
      console.log('the end');
      fs.readFile("./node-view.html", function (err, data) {
        // res.writeHead(200, { "Content-Type": "text/html" });
        res.write(data);
        res.end();
      });
    } else {
        fs.readFile("./index.html", function (err, data) {
            // res.writeHead(200, { "Content-Type": "text/html" });
            res.write(data);
            res.end();
        });
      }
    })
    .listen(8080); //the server object listens on port 8080

    let xlPath1 = path.join(process.cwd(), "input/File-1.xlsx");
    let xlPath2 = path.join(process.cwd(), "input/File-2.xlsx");
    var XLSX = require("xlsx");
    var workbook1 = XLSX.readFile(xlPath1);
    var workbook2 = XLSX.readFile(xlPath2);
    let result1 = XLSX.utils.sheet_to_json(workbook1.Sheets["Core MSS 043020"]);
    let result2 = XLSX.utils.sheet_to_json(workbook2.Sheets["Core MSS 053120"]);
    let array1 = _.uniqBy(result1, "Global Manager");
    let array2 = _.uniqBy(result2, "Global Manager");
    let uniqueGMs2 = [];
    let uniqueGMs1 = [];
    let d3Structure = {
      name : "IBM",
      parent : null,
      value : 35,
    }
    _.forEach(array1, (item) => {
      let newItem = _.pick(item, "Global Manager");
      uniqueGMs1.push(newItem);
    });
    _.forEach(array2, (item) => {
      let newItem = _.pick(item, "Global Manager");
      uniqueGMs2.push(newItem);
    });
    // console.log(uniqueGMs1, uniqueGMs2);
    let commonValue = _.intersectionBy(uniqueGMs1, uniqueGMs2, "Global Manager");
    let unionOfManager = _.unionBy(uniqueGMs1, uniqueGMs2, "Global Manager");
    // removed (red in color)
    let presentIn1ButNotIn2 = _.differenceBy(uniqueGMs1, commonValue, "Global Manager");
    // Added (green in color)
    let presentIn2ButNotIn1 = _.differenceBy(uniqueGMs2, commonValue, "Global Manager");
    let level1 = [];
    unionOfManager.forEach(manager => {
      let temp;
      let removedOne = _.intersectionBy([manager], presentIn1ButNotIn2, "Global Manager");
      let addedOne = _.intersectionBy([manager], presentIn2ButNotIn1, "Global Manager");
      if(removedOne.length > 0) {
        temp = {
          name : manager["Global Manager"],
          parent : "IBM",
          value : 20,
          type: "grey",
          level: "red",
        }
      } else if(addedOne.length > 0) {
          temp = {
            name : manager["Global Manager"],
            parent : "IBM",
            value : 20,
            type: "grey",
            level: "green",
          }
        } 
        else {
          temp = {
            name : manager["Global Manager"],
            parent : "IBM",
            value : 20,
          }
        }
          if(temp) {
            // let array1 = ;
            // let array2 =;
            let unqList1 = _.filter(result1, (a) => a["Global Manager"] == manager["Global Manager"]);
            let unqList2 = _.filter(result2, (a) => a["Global Manager"] == manager["Global Manager"]);
            temp.children = constructNode(manager, "Global Manager", "In-Country Manager", _.uniqBy(unqList1, "In-Country Manager"), _.uniqBy(unqList2, "In-Country Manager"));
            level1.push(temp);
          }
      })
      d3Structure.children = level1;
      // console.log("done");                                        // return all the child of GM
      function constructNode(parentObj, parentKey, childKey, list1, list2 ) {
        // let unqList1 = _.filter(array1, (a) => a[parentKey] == parentObj[parentKey]);
        // let unqList2 = _.filter(array2, (a) => a[parentKey] == parentObj[parentKey]);
        let commonList = _.intersectionBy(list1, list2, childKey);
        let union = _.unionBy(list1, list2, childKey);
        // removed (red in color)
        let presentIn1ButNotIn2 = _.differenceBy(list1, commonList, childKey);
        // Added (green in color)
        let presentIn2ButNotIn1 = _.differenceBy(list2, commonList, childKey);
        let data = [];
        union.forEach(unionValue => {
          let temp;
          let removedOne = _.intersectionBy([unionValue], presentIn1ButNotIn2, childKey);
          let addedOne = _.intersectionBy([unionValue], presentIn2ButNotIn1, childKey);
          if(removedOne.length > 0) {
            temp = {
              name : unionValue[childKey],
              parent : parentObj[parentKey],
              value : 20,
              type: "grey",
              level: "red",
              }
          } else if(addedOne.length > 0) {
              temp = {
                name : unionValue[childKey],
                parent : parentObj[parentKey],
                value : 20,
                type: "grey",
                level: "green",
              }
          } else {
                temp = {
                  name : unionValue[childKey],
                  parent : parentObj[parentKey],
                  value : 20,
                }
          }
          if(temp) {
                temp.children = [];
                let unqReportee1 = _.filter(result1, (a) => a[childKey] == unionValue[childKey]);
                let unqReportee2 = _.filter(result2, (a) => a[childKey] == unionValue[childKey]);
                let commonReprte = _.intersectionBy(unqReportee1, unqReportee2, "Lotus Notes ID");
                let unionOfReportee = _.unionBy(unqReportee1, unqReportee2, "Lotus Notes ID");
                // removed (red in color)
                let reporteePresentIn1ButNotIn2 = _.differenceBy(unqReportee1, commonReprte, "Lotus Notes ID");
                // Added (green in color)
                let reporteePresentIn2ButNotIn1 = _.differenceBy(unqReportee2, commonReprte, "Lotus Notes ID");
                unionOfReportee.forEach(unqReportee => {
                  let reportee;
                  let removedReportee = _.intersectionBy([unqReportee], reporteePresentIn1ButNotIn2, "Lotus Notes ID");
                  let addedReportee = _.intersectionBy([unqReportee], reporteePresentIn2ButNotIn1, "Lotus Notes ID");
                  if(removedReportee.length > 0) {
                    reportee = {
                      name : unqReportee["Lotus Notes ID"],
                      parent : unionValue[childKey],
                      value : 20,
                      type: "grey",
                      level: "red",
                      }
                  } else if(addedReportee.length > 0) {
                      reportee = {
                          name : unqReportee["Lotus Notes ID"],
                          parent : unionValue[childKey],
                          value : 20,
                          type: "grey",
                          level: "green",
                        }
                      } else {
                        reportee = {
                          name : unqReportee["Lotus Notes ID"],
                          parent : unionValue[childKey],
                          value : 20,
                          }
                      }
                    temp.children.push(reportee);
                  });
                  data.push(temp);
          }
        })
      return data;
      }