var express = require("express");
var bodyParser = require("body-parser");
var multer = require("multer");
var app = express();
var XLSX = require("xlsx");
const fs = require("fs");
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");
const path = require("path");
const _ = require("lodash");
const { log } = require("console");

let showLevel2AllNode = true;
let ShowOnlyChangedNodeForLevel2 = false;
let showAllLevel1Node = true;
let showOnlyChangedLevel1Node = false;
let showOnlyRed = false;
let showOnlyGreen = false;
let GMs = [];
let ICMGs = [];
let RPts = [];
let moveinout = [];

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "/public/")));

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./archive");
  },
  filename: function (req, file, callback) {
    var datetimestamp = Date.now();
    callback(
      null,
      file.fieldname +
        "-" +
        datetimestamp +
        "." +
        file.originalname.split(".")[file.originalname.split(".").length - 1]
    );
  },
});

var upload = multer({
  storage: storage,
  fileFilter: function (req, file, callback) {
    if (
      ["xls", "xlsx",].indexOf(
        file.originalname.split(".")[file.originalname.split(".").length - 1]
      ) === -1
    ) {
      return callback(new Error("Wrong extension type"));
    }
    callback(null, true);
  },
}).array("file", 2);

app.get("/table-view", function (req, res) {
  res.sendFile(__dirname + "/index.html");
});
app.get("/node-view", function (req, res) {
  res.sendFile(__dirname + "/node-view.html");
});

app.get("/t_data", function (req, res) {
  res.write(JSON.stringify([GMs, ICMGs, RPts]));
  res.end();
});

app.get("/data", function (req, res) {
  switch (req.query.type) {
    case "all":
      showLevel2AllNode = true;
      ShowOnlyChangedNodeForLevel2 = false;
      showAllLevel1Node = true;
      showOnlyChangedLevel1Node = false;
      // Move in and Move out
      showOnlyRed = false;
      showOnlyGreen = false;
      loadD3StructureJSON();
      break;

    case "green":
      showLevel2AllNode = false;
      ShowOnlyChangedNodeForLevel2 = true;
      showAllLevel1Node = false;
      showOnlyChangedLevel1Node = true;
      // Move in and Move out
      showOnlyRed = false;
      showOnlyGreen = true;
      loadD3StructureJSON();
      break;

    case "change":
      showLevel2AllNode = false;
      ShowOnlyChangedNodeForLevel2 = true;
      showAllLevel1Node = false;
      showOnlyChangedLevel1Node = true;
      // Move in and Move out
      showOnlyRed = false;
      showOnlyGreen = false;
      loadD3StructureJSON();
      break;

    case "red":
      showLevel2AllNode = false;
      ShowOnlyChangedNodeForLevel2 = true;
      showAllLevel1Node = false;
      showOnlyChangedLevel1Node = true;
      // Move in and Move out
      showOnlyRed = true;
      showOnlyGreen = false;
      loadD3StructureJSON();
      break;

 
    default:
      break;
  }

  let d3 = [d3Structure];
  res.write(JSON.stringify(d3));
  res.end();
});
let xlPath1 = path.join(process.cwd(), "input/File-1.xlsx");
let xlPath2 = path.join(process.cwd(), "input/File-2.xlsx");
var workbook1 = XLSX.readFile(xlPath1);
var workbook2 = XLSX.readFile(xlPath2);
// let workbook3;
let result1 = XLSX.utils.sheet_to_json(workbook1.Sheets["Core MSS 043020"]);
let result2 = XLSX.utils.sheet_to_json(workbook2.Sheets["Core MSS 053120"]);
let uniqueGMs1 = _.uniqBy(result1, "Global Manager");
let uniqueGMs2 = _.uniqBy(result2, "Global Manager");
let d3Structure = {
  name: "IBM",
  parent: null,
  value: 35,
};
let commonValue = _.intersectionBy(uniqueGMs1, uniqueGMs2, "Global Manager");
let unionOfManager = _.unionBy(uniqueGMs1, uniqueGMs2, "Global Manager");
// removed (Moved out color)
let presentIn1ButNotIn2 = _.differenceBy(
  uniqueGMs1,
  commonValue,
  "Global Manager"
);
// Added (Moved in color)
let presentIn2ButNotIn1 = _.differenceBy(
  uniqueGMs2,
  commonValue,
  "Global Manager"
);

loadD3StructureJSON();

function loadD3StructureJSON() {
  let level1 = [];
  unionOfManager.forEach((manager) => {
    let temp;
    let removedOne = _.intersectionBy(
      [manager],
      presentIn1ButNotIn2,
      "Global Manager"
    );
    let addedOne = _.intersectionBy(
      [manager],
      presentIn2ButNotIn1,
      "Global Manager"
    );
    if (removedOne.length > 0) {
      if (!showOnlyGreen) {
        temp = {
          name: manager["Global Manager"],
          parent: "IBM",
          value: 20,
          type: "grey",
          level: "red",
        };
      }
      GMs.push(
        _.assign(manager, { type: "Global Manager", status: "moved in" })
      );
    } else if (addedOne.length > 0) {
      if (!showOnlyRed) {
        temp = {
          name: manager["Global Manager"],
          parent: "IBM",
          value: 20,
          type: "grey",
          level: "green",
        };
      }
      GMs.push(
        _.assign(manager, { type: "Global Manager", status: "moved in" })
      );
    } else {
      if (showAllLevel1Node) {
        temp = {
          name: manager["Global Manager"],
          parent: "IBM",
          value: 20,
        };
      } else if (showOnlyChangedLevel1Node) {
        let valid = HasNodeChange(manager);
        if (valid) {
          temp = {
            name: manager["Global Manager"],
            parent: "IBM",
            value: 20,
          };
        }
      }
    }
    if (temp) {
      let unqList1 = _.filter(
        result1,
        (a) => a["Global Manager"] == manager["Global Manager"]
      );
      let unqList2 = _.filter(
        result2,
        (a) => a["Global Manager"] == manager["Global Manager"]
      );
      temp.children = constructNode(
        manager,
        "Global Manager",
        "In-Country Manager",
        _.uniqBy(unqList1, "In-Country Manager"),
        _.uniqBy(unqList2, "In-Country Manager")
      );
      level1.push(temp);
    }
  });
  d3Structure.children = level1;
}

function constructNode(parentObj, parentKey, childKey, list1, list2) {
  let commonList = _.intersectionBy(list1, list2, childKey);
  let union = _.unionBy(list1, list2, childKey);
  // removed (Moved out color)
  let presentIn1ButNotIn2 = _.differenceBy(list1, commonList, childKey);
  // Added (Moved in color)
  let presentIn2ButNotIn1 = _.differenceBy(list2, commonList, childKey);
  let data = [];
  union.forEach((unionValue) => {
    let temp;
    let removedOne = _.intersectionBy(
      [unionValue],
      presentIn1ButNotIn2,
      childKey
    );
    let addedOne = _.intersectionBy(
      [unionValue],
      presentIn2ButNotIn1,
      childKey
    );
    if (removedOne.length > 0) {
      if (!showOnlyGreen) {
        temp = {
          name: unionValue[childKey],
          parent: parentObj[parentKey],
          value: 20,
          type: "grey",
          level: "red",
        };
      }
      ICMGs.push(_.assign(unionValue, { type: childKey, status: "moved out" }));
    } else if (addedOne.length > 0) {
      if (!showOnlyRed) {
        temp = {
          name: unionValue[childKey],
          parent: parentObj[parentKey],
          value: 20,
          type: "grey",
          level: "green",
        };
      }
      ICMGs.push(_.assign(unionValue, { type: childKey, status: "moved in" }));
    } else {
      if (showLevel2AllNode) {
        temp = {
          name: unionValue[childKey],
          parent: parentObj[parentKey],
          value: 20,
        };
      } else if (ShowOnlyChangedNodeForLevel2) {
        let valid = HasChangeLevel3(unionValue);
        if (valid) {
          temp = {
            name: unionValue[childKey],
            parent: parentObj[parentKey],
            value: 20,
          };
        }
      }
    }
    if (temp) {
      temp.children = [];
      let unqReportee1 = _.filter(
        result1,
        (a) => a[childKey] == unionValue[childKey]
      );
      let unqReportee2 = _.filter(
        result2,
        (a) => a[childKey] == unionValue[childKey]
      );
      let commonReprte = _.intersectionBy(
        unqReportee1,
        unqReportee2,
        "Lotus Notes ID"
      );
      let unionOfReportee = _.unionBy(
        unqReportee1,
        unqReportee2,
        "Lotus Notes ID"
      );
      // removed (Moved out color)
      let reporteePresentIn1ButNotIn2 = _.differenceBy(
        unqReportee1,
        commonReprte,
        "Lotus Notes ID"
      );
      // Added (Moved in color)
      let reporteePresentIn2ButNotIn1 = _.differenceBy(
        unqReportee2,
        commonReprte,
        "Lotus Notes ID"
      );
      unionOfReportee.forEach((unqReportee) => {
        let reportee;
        let removedReportee = _.intersectionBy(
          [unqReportee],
          reporteePresentIn1ButNotIn2,
          "Lotus Notes ID"
        );
        let addedReportee = _.intersectionBy(
          [unqReportee],
          reporteePresentIn2ButNotIn1,
          "Lotus Notes ID"
        );
        if (removedReportee.length > 0) {
          if (!showOnlyGreen) {
            reportee = {
              name: unqReportee["Lotus Notes ID"],
              parent: unionValue[childKey],
              value: 20,
              type: "grey",
              level: "red",
            };
          }
          RPts.push(
            _.assign(unqReportee, {
              type: "Lotus Notes ID",
              status: "moved out",
            })
          );
        } else if (addedReportee.length > 0) {
          if (!showOnlyRed) {
            reportee = {
              name: unqReportee["Lotus Notes ID"],
              parent: unionValue[childKey],
              value: 20,
              type: "grey",
              level: "green",
            };
          }
          RPts.push(
            _.assign(unqReportee, {
              type: "Lotus Notes ID",
              status: "moved in",
            })
          );
        } else {
          reportee = {
            name: unqReportee["Lotus Notes ID"],
            parent: unionValue[childKey],
            value: 20,
          };
        }
        if (reportee) {
          temp.children.push(reportee);
        }
      });
      data.push(temp);
    }
  });
  return data;
}

app.post("/api/upload", function (req, res) {
  upload(req, res, function (err) {
    var file1 = req.files[0].filename;
    var file2 = req.files[1].filename;
    if (file1.split(".")[file1.split(".").length - 1] === "xlsx") {
      exceltojson = xlsxtojson;
    } else {
      exceltojson = xlstojson;
    }
    try {
      exceltojson(
        {
          input: "./archive/" + file1,
          output: "./archive/" + file1,
          lowerCaseHeaders: true,
        },
        function (err, result1) {
          if (err) {
          } else {
            exceltojson(
              {
                input: "./archive/" + file2,
                output: "./archive/" + file2,
                lowerCaseHeaders: true,
              },
              function (err, result2) {
                if (err) {
                } else {
                  var difference1 = result1.filter((x) => !result2.includes(x));
                  var difference2 = result2.filter((x) => !result1.includes(x));
                  res.status(200).json({ diff: [difference2, difference1] });
                }
              }
            );
          }
        }
      );
    } catch (e) {}

    if (err) {
      return res.end("Error uploading file.");
    }
  });
});

app.listen(8080, function () {
  console.log("Working on port 8080");
  console.log("please wait....");
  console.log("Visit http://localhost:8080/node-view");
});

function HasChangeLevel3(unionValue) {
  let childKey = "In-Country Manager";
  let unqReportee1 = _.filter(
    result1,
    (a) => a[childKey] == unionValue[childKey]
  );
  let unqReportee2 = _.filter(
    result2,
    (a) => a[childKey] == unionValue[childKey]
  );
  let commonReprte = _.intersectionBy(
    unqReportee1,
    unqReportee2,
    "Lotus Notes ID"
  );
  let unionOfReportee = _.unionBy(unqReportee1, unqReportee2, "Lotus Notes ID");
  // removed (Moved out color)
  let reporteePresentIn1ButNotIn2 = _.differenceBy(
    unqReportee1,
    commonReprte,
    "Lotus Notes ID"
  );
  // Added (Moved in color)
  let reporteePresentIn2ButNotIn1 = _.differenceBy(
    unqReportee2,
    commonReprte,
    "Lotus Notes ID"
  );
  let result = unionOfReportee.find((unqReportee) => {
    let removedReportee = _.intersectionBy(
      [unqReportee],
      reporteePresentIn1ButNotIn2,
      "Lotus Notes ID"
    );
    let addedReportee = _.intersectionBy(
      [unqReportee],
      reporteePresentIn2ButNotIn1,
      "Lotus Notes ID"
    );

    if (removedReportee.length > 0 || addedReportee.length > 0) {
      return true;
    }
  });

  return Boolean(result);
}

function HasNodeChange(gm) {
  let status;
  let unqList1 = _.filter(
    result1,
    (a) => a["Global Manager"] == gm["Global Manager"]
  );
  let unqList2 = _.filter(
    result2,
    (a) => a["Global Manager"] == gm["Global Manager"]
  );
  let list1 = _.uniqBy(unqList1, "In-Country Manager");
  let list2 = _.uniqBy(unqList2, "In-Country Manager");
  let commonList = _.intersectionBy(list1, list2, "In-Country Manager");
  let union = _.unionBy(list1, list2, "In-Country Manager");
  // removed (Moved out color)
  let presentIn1ButNotIn2 = _.differenceBy(
    list1,
    commonList,
    "In-Country Manager"
  );
  // Added (Moved in color)
  let presentIn2ButNotIn1 = _.differenceBy(
    list2,
    commonList,
    "In-Country Manager"
  );
  let result = union.find((unionValue) => {
    let removedOne = _.intersectionBy(
      [unionValue],
      presentIn1ButNotIn2,
      "In-Country Manager"
    );
    let addedOne = _.intersectionBy(
      [unionValue],
      presentIn2ButNotIn1,
      "In-Country Manager"
    );
    if (removedOne.length > 0 || addedOne.length > 0) {
      return true;
    }
  });
  return Boolean(result);
}
